package Clases;

public class Golosinas {
    String Soda,PalomitasMedianas,hotDogs,PalomitasGrandes;
    Double precioUnidad;

    public Golosinas(String Soda, String PalomitasMedianas, String hotDogs, String PalomitasGrandes) {
        this.Soda ="Soda";
        this.PalomitasMedianas = "Palomitas Medianas";
        this.hotDogs = "Hot Dogs";
        this.PalomitasGrandes = "Palomitas Grandes";
    }

    public double ComprarGolosinas(){
        return 0;
    }
      

    public String getSoda() {
        return Soda;
    }

    public void setSoda(String Soda) {
        this.Soda = Soda;
    }

    public String getPalomitasMedianas() {
        return PalomitasMedianas;
    }

    public void setPalomitasMedianas(String PalomitasMedianas) {
        this.PalomitasMedianas = PalomitasMedianas;
    }

    public String getHotDogs() {
        return hotDogs;
    }

    public void setHotDogs(String hotDogs) {
        this.hotDogs = hotDogs;
    }

    public String getPalomitasGrandes() {
        return PalomitasGrandes;
    }

    public void setPalomitasGrandes(String PalomitasGrandes) {
        this.PalomitasGrandes = PalomitasGrandes;
    }    
}
