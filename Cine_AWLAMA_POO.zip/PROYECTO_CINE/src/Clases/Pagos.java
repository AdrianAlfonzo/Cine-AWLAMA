package Clases;

public class Pagos {
    String tarjetaClub, tarjetaDebito, tarjetaCredito, payPal;

    public Pagos(String tarjetaClub, String tarjetaDebito, String tarjetaCredito, String payPal) {
        this.tarjetaClub = tarjetaClub;
        this.tarjetaDebito = tarjetaDebito;
        this.tarjetaCredito = tarjetaCredito;
        this.payPal = payPal;
    }
     public double Pagar(){
         return 0;         
     }

    public String getTarjetaClub() {
        return tarjetaClub;
    }

    public void setTarjetaClub(String tarjetaClub) {
        this.tarjetaClub = tarjetaClub;
    }

    public String getTarjetaDebito() {
        return tarjetaDebito;
    }

    public void setTarjetaDebito(String tarjetaDebito) {
        this.tarjetaDebito = tarjetaDebito;
    }

    public String getTarjetaCredito() {
        return tarjetaCredito;
    }

    public void setTarjetaCredito(String tarjetaCredito) {
        this.tarjetaCredito = tarjetaCredito;
    }

    public String getPayPal() {
        return payPal;
    }

    public void setPayPal(String payPal) {
        this.payPal = payPal;
    }
     
}
