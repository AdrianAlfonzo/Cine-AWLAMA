package Clases;

public class Peliculas {
    String EndGame,DeadPool, BusquedaImplacable,Pixeles,Dumbo,Moana,Frozen2,KungFuPanda;
  String clasificacion, idioma,director,sinopsis;
  int duracion;

    public Peliculas(String clasificacion, String idioma, String director, String sinopsis, int duracion) {
        this.clasificacion = clasificacion;
        this.idioma = idioma;
        this.director = director;
        this.sinopsis = sinopsis;
        this.duracion = duracion;
    }

    public Peliculas(String EndGame,String DeadPool, String BusquedaImplacable, String Pixeles, String Dumbo, String Moana, String Frozen2, String KungFuPanda) {
        this.EndGame ="Avengers:End Game";
        this.DeadPool = "Dead Pool";
        this.BusquedaImplacable = "Busqueda Implacable";
        this.Pixeles = "Pixeles";
        this.Dumbo = "Dumbo";
        this.Moana = "Moana";
        this.Frozen2 = "Frozen 2";
        this.KungFuPanda = "Kung Fu Panda";
    }
   

    public String getEndGame() {
        return EndGame;
    }

    public void setEndGame(String EndGame) {
        this.EndGame = EndGame;
    }

    public String getDeadPool() {
        return DeadPool;
    }

    public void setDeadPool(String DeadPool) {
        this.DeadPool = DeadPool;
    }

    public String getBusquedaImplacable() {
        return BusquedaImplacable;
    }

    public void setBusquedaImplacable(String BusquedaImplacable) {
        this.BusquedaImplacable = BusquedaImplacable;
    }

    public String getPixeles() {
        return Pixeles;
    }

    public void setPixeles(String Pixeles) {
        this.Pixeles = Pixeles;
    }

    public String getDumbo() {
        return Dumbo;
    }

    public void setDumbo(String Dumbo) {
        this.Dumbo = Dumbo;
    }

    public String getMoana() {
        return Moana;
    }

    public void setMoana(String Moana) {
        this.Moana = Moana;
    }

    public String getFrozen2() {
        return Frozen2;
    }

    public void setFrozen2(String Frozen2) {
        this.Frozen2 = Frozen2;
    }

    public String getKungFuPanda() {
        return KungFuPanda;
    }

    public void setKungFuPanda(String KungFuPanda) {
        this.KungFuPanda = KungFuPanda;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    
    
}
