package Clases;

public class Reserva {
    int boletoAdulto, boletoAdultoMayor,boletoNinio;
    String butacas;

    public Reserva(int boletoAdulto, int boletoAdultoMayor, int boletoNinio, String butacas) {
        this.boletoAdulto = boletoAdulto;
        this.boletoAdultoMayor = boletoAdultoMayor;
        this.boletoNinio = boletoNinio;
        this.butacas = butacas;
    }

    public int getBoletoAdulto() {
        return boletoAdulto;
    }

    public void setBoletoAdulto(int boletoAdulto) {
        this.boletoAdulto = boletoAdulto;
    }

    public int getBoletoAdultoMayor() {
        return boletoAdultoMayor;
    }

    public void setBoletoAdultoMayor(int boletoAdultoMayor) {
        this.boletoAdultoMayor = boletoAdultoMayor;
    }

    public int getBoletoNinio() {
        return boletoNinio;
    }

    public void setBoletoNinio(int boletoNinio) {
        this.boletoNinio = boletoNinio;
    }

    public String getButacas() {
        return butacas;
    }

    public void setButacas(String butacas) {
        this.butacas = butacas;
    }
    
}
