package Clases;

public class Cliente {

    String nombreCliente;
    String duiCliente;
    String correoCliente;

    public Cliente(String nombreCliente, String duiCliente, String correoCliente) {
        this.nombreCliente = nombreCliente;
        this.duiCliente = duiCliente;
        this.correoCliente = correoCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getDuiCliente() {
        return duiCliente;
    }

    public void setDuiCliente(String duiCliente) {
        this.duiCliente = duiCliente;
    }

    public String getCorreoCliente() {
        return correoCliente;
    }

    public void setCorreoCliente(String correoCliente) {
        this.correoCliente = correoCliente;
    }

}
