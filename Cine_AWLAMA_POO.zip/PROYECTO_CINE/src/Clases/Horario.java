package Clases;

public class Horario {
    int horaFuncion;

    public Horario(int horaFuncion) {
        this.horaFuncion = horaFuncion;
    }

    public int getHoraFuncion() {
        return horaFuncion;
    }

    public void setHoraFuncion(int horaFuncion) {
        this.horaFuncion = horaFuncion;
    }
    
}
