package Clases;

public class Sala {
    String tipoSala;

    public Sala(String tipoSala) {
        this.tipoSala = tipoSala;
    }

    public String getTipoSala() {
        return tipoSala;
    }

    public void setTipoSala(String tipoSala) {
        this.tipoSala = tipoSala;
    }
    
}
