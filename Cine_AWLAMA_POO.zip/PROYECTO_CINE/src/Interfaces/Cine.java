//Cine AWLAMA - 2020
//Andy William, Luis Adrián, Miguel Ángel
package Interfaces;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.io.IOException;
import javax.swing.ImageIcon;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

public class Cine extends javax.swing.JFrame {

    DefaultTableModel modeloPelicula;
    DefaultTableModel modeloComida;
    DefaultTableModel modeloSala;

    int cantidadAsiento;
    int numeroVenta;
    double totalVentas;

    public void MostrarVista() {
        this.TabbedMainPane.setEnabledAt(0, false);
        this.TabbedMainPane.setEnabledAt(1, true);
        this.TabbedMainPane.setEnabledAt(2, true);
        this.TabbedMainPane.setEnabledAt(3, true);
        this.TabbedMainPane.setEnabledAt(4, true);

        this.jLabelBusquedaImplacable.setEnabled(false);
        this.jLabelEndGame.setEnabled(false);
        this.jLabelDeadPool.setEnabled(false);
        this.jLabelPixeles.setEnabled(false);
        this.jLabelDumbo.setEnabled(false);
        this.jLabelMoana.setEnabled(false);
        this.jLabelFrozen.setEnabled(false);
        this.jLabelKungFuPanda.setEnabled(false);

        this.jSpinnerBoletoAdulto.setEnabled(false);
        this.jSpinnerBoletoAdultoMAyor.setEnabled(false);
        this.jSpinnerBoletoÑino.setEnabled(false);
    }

    public void ValidarAsiento() {
        this.cantidadAsiento++;
        if (Asiento()+2 == cantidadAsiento) {
            JOptionPane.showMessageDialog(null, "Movimiento inválido: Seleccionaste más asientos de los que compraste.", "Error: Redirigiendo a dulcería...", JOptionPane.INFORMATION_MESSAGE);
            this.TabbedMainPane.setEnabledAt(1, false);
            this.TabbedMainPane.setSelectedIndex(2);
        }
    }

    public int Asiento() {
        this.jSpinnerBoletoAdulto.getValue().toString();
        this.jSpinnerBoletoAdultoMAyor.getValue().toString();
        this.jSpinnerBoletoÑino.getValue().toString();
        int cantidad;
        cantidad = Integer.parseInt(this.jSpinnerBoletoAdulto.getValue().toString()) + Integer.parseInt(this.jSpinnerBoletoAdultoMAyor.getValue().toString()) + Integer.parseInt(this.jSpinnerBoletoÑino.getValue().toString());
        return cantidad;
    }

    public Cine() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Pictures/PNG_mini.png")).getImage());
        cantidadAsiento = 0;

        this.modeloPelicula = (DefaultTableModel) this.jTablePELICULAS.getModel();
        this.modeloSala = (DefaultTableModel) this.jTableSALA_ASIENTOS.getModel();
        this.modeloComida = (DefaultTableModel) this.jTableCOMIDA.getModel();
        this.setExtendedState(MAXIMIZED_BOTH);

        this.TabbedMainPane.setEnabled(true);
        this.TabbedMainPane.setEnabled(true);
        this.TabbedMainPane.setEnabled(true);
        this.TabbedMainPane.setEnabled(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_NOMBRE.setVisible(false);
        this.jLabelCLUB_NOMBRE.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_DUI.setVisible(false);
        this.jLabelCLUB_DUI.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_NUMTARJETA.setVisible(false);
        this.jLabelCLUB_NUMTARJETA.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NOMBRE.setVisible(false);
        this.jLabelVISA_NOMBRE.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_DUI.setVisible(false);
        this.jLabelVISA_DUI.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NUMTARJETA.setVisible(false);
        this.jLabelContraseniaPago.setVisible(false);
        /////////////////////////////////////////////////////////////////////////////////////////////////
        this.jPanel6.setVisible(false);
        /////////////////////////////////////////////////////////////////////////////////////////////////
        this.txtTotalPorGolosinas.setText(Double.toString(TotalPagarGolosinas()));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        TabbedMainPane = new javax.swing.JTabbedPane();
        jPanDESPACHO_BOLETOS = new javax.swing.JPanel();
        jDesktopPane5 = new javax.swing.JDesktopPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSpinnerBoletoAdulto = new javax.swing.JSpinner();
        jLabel5 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabelPeliculaNombre = new javax.swing.JLabel();
        jLabelPRECIOTOTALBOLETOS = new javax.swing.JLabel();
        jLabelPRECIO = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jSpinnerBoletoAdultoMAyor = new javax.swing.JSpinner();
        jLabel6 = new javax.swing.JLabel();
        jSpinnerBoletoÑino = new javax.swing.JSpinner();
        jLabel60 = new javax.swing.JLabel();
        jLabelBusquedaImplacable = new javax.swing.JLabel();
        jLabelEndGame = new javax.swing.JLabel();
        jLabelDeadPool = new javax.swing.JLabel();
        jLabelDumbo = new javax.swing.JLabel();
        jLabelMoana = new javax.swing.JLabel();
        jLabelPixeles = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabelFrozen = new javax.swing.JLabel();
        jLabelKungFuPanda = new javax.swing.JLabel();
        lblAVtexto = new javax.swing.JLabel();
        lblDeadTexto = new javax.swing.JLabel();
        bllBusquedaTexto = new javax.swing.JLabel();
        lblPixelsTexto = new javax.swing.JLabel();
        lblDumboTexto = new javax.swing.JLabel();
        lblMoanaTexto = new javax.swing.JLabel();
        lblFrozenTexto = new javax.swing.JLabel();
        lblKFPTexto = new javax.swing.JLabel();
        jPanESCOGER_SALA = new javax.swing.JPanel();
        jDesktopPane2 = new javax.swing.JDesktopPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jComboBoxSALAS = new javax.swing.JComboBox<>();
        jComboBoxFUNCIONES = new javax.swing.JComboBox<>();
        jButtonSIGUIENTE = new javax.swing.JButton();
        jButtonAsientoA2 = new javax.swing.JButton();
        jButtonAsientoA1 = new javax.swing.JButton();
        jButtonAsientoA3 = new javax.swing.JButton();
        jButtonAsientoA4 = new javax.swing.JButton();
        jButtonAsientoA5 = new javax.swing.JButton();
        jButtonAsientoA6 = new javax.swing.JButton();
        jButtonAsientoA8 = new javax.swing.JButton();
        jButtonAsientoA7 = new javax.swing.JButton();
        jButtonAsientoA9 = new javax.swing.JButton();
        jButtonAsientoA10 = new javax.swing.JButton();
        jButtonAsientoB1 = new javax.swing.JButton();
        jButtonAsientoB2 = new javax.swing.JButton();
        jButtonAsientoB3 = new javax.swing.JButton();
        jButtonAsientoB4 = new javax.swing.JButton();
        jButtonAsientoB5 = new javax.swing.JButton();
        jButtonAsientoB6 = new javax.swing.JButton();
        jButtonAsientoB7 = new javax.swing.JButton();
        jButtonAsientoB8 = new javax.swing.JButton();
        jButtonAsientoB9 = new javax.swing.JButton();
        jButtonAsientoB10 = new javax.swing.JButton();
        jButtonAsientoD1 = new javax.swing.JButton();
        jButtonAsientoD8 = new javax.swing.JButton();
        jButtonAsientoD5 = new javax.swing.JButton();
        jButtonAsientoD4 = new javax.swing.JButton();
        jButtonAsientoD3 = new javax.swing.JButton();
        jButtonAsientoD6 = new javax.swing.JButton();
        jButtonAsientoD9 = new javax.swing.JButton();
        jButtonAsientoD7 = new javax.swing.JButton();
        jButtonAsientoD2 = new javax.swing.JButton();
        jButtonAsientoD10 = new javax.swing.JButton();
        jButtonAsientoC1 = new javax.swing.JButton();
        jButtonAsientoC2 = new javax.swing.JButton();
        jButtonAsientoC3 = new javax.swing.JButton();
        jButtonAsientoC4 = new javax.swing.JButton();
        jButtonAsientoC5 = new javax.swing.JButton();
        jButtonAsientoC6 = new javax.swing.JButton();
        jButtonAsientoC7 = new javax.swing.JButton();
        jButtonAsientoC8 = new javax.swing.JButton();
        jButtonAsientoC9 = new javax.swing.JButton();
        jButtonAsientoC10 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jPanESCOGER_GOLOSINAS = new javax.swing.JPanel();
        jDesktopPane3 = new javax.swing.JDesktopPane();
        jButtonSoda = new javax.swing.JButton();
        jButtonPalomitasMedianas = new javax.swing.JButton();
        jButtonHotDogs = new javax.swing.JButton();
        jButtonPalomitasGrandes = new javax.swing.JButton();
        jLabel55 = new javax.swing.JLabel();
        jLabelCUANTASODAS = new javax.swing.JLabel();
        jLabelINDICACIONES = new javax.swing.JLabel();
        jSpinnerPALOMITASM = new javax.swing.JSpinner();
        jSpinnerHOTDOGS = new javax.swing.JSpinner();
        jLabelCUANTAHOTDOG = new javax.swing.JLabel();
        jLabelCUANTASPALIMITASG = new javax.swing.JLabel();
        jSpinnerPALOMITASG = new javax.swing.JSpinner();
        jButtonCONFORMAR_GOLOSINAS = new javax.swing.JButton();
        jSpinnerSODA = new javax.swing.JSpinner();
        jLabelCUANTASPALOMITASM1 = new javax.swing.JLabel();
        lblIndicacion = new javax.swing.JLabel();
        lblSodaTexto = new javax.swing.JLabel();
        lblPalomitasMTexto = new javax.swing.JLabel();
        lblHotDogsTexto = new javax.swing.JLabel();
        lblPalomitasGTexto = new javax.swing.JLabel();
        jPanDETALLE_VENTA = new javax.swing.JPanel();
        jDesktopPane4 = new javax.swing.JDesktopPane();
        jDesktopPane6 = new javax.swing.JDesktopPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePELICULAS = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableCOMIDA = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTableSALA_ASIENTOS = new javax.swing.JTable();
        jLabel56 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        txtTotalPorGolosinas = new javax.swing.JTextField();
        jLabel66 = new javax.swing.JLabel();
        txtTotalPagar = new javax.swing.JTextField();
        jPanMETODOS_PAGO = new javax.swing.JPanel();
        jDesktopPane7 = new javax.swing.JDesktopPane();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jButtonTARJETA_VISA = new javax.swing.JButton();
        jButtonPAYPAL = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabelCLUB_NOMBRE = new javax.swing.JLabel();
        jTextFieldVISA_NOMBRE = new javax.swing.JTextField();
        jLabelCLUB_DUI = new javax.swing.JLabel();
        jTextFieldVISA_DUI = new javax.swing.JTextField();
        jLabelCLUB_NUMTARJETA = new javax.swing.JLabel();
        jTextFieldVISA_NUMTARJETA = new javax.swing.JTextField();
        jTextFieldCLUB_NUMTARJETA = new javax.swing.JTextField();
        jTextFieldCLUB_NOMBRE = new javax.swing.JTextField();
        jLabelContraseniaPago = new javax.swing.JLabel();
        jLabelVISA_NOMBRE = new javax.swing.JLabel();
        jLabelVISA_DUI = new javax.swing.JLabel();
        jTextFieldCLUB_DUI = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabelCorreo = new javax.swing.JLabel();
        jTextFieldCorreo = new javax.swing.JTextField();
        jLabelVISA_NUMTARJETA = new javax.swing.JLabel();
        jButtonSALIR = new javax.swing.JButton();
        jLabel67 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        btnPDF = new javax.swing.JButton();
        jButtonTARJETA_CLUB = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel59 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuInicio = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();

        jMenuItem7.setText("jMenuItem7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cine AWLAMA: ¡Bienvenido!");
        setUndecorated(true);
        getContentPane().setLayout(null);

        TabbedMainPane.setBackground(new java.awt.Color(102, 102, 255));
        TabbedMainPane.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        TabbedMainPane.setToolTipText("");
        TabbedMainPane.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        TabbedMainPane.setName(""); // NOI18N
        TabbedMainPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabbedMainPaneMouseClicked(evt);
            }
        });

        jPanel4.setLayout(null);

        jLabel61.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/entradas-de-cine-para-una-pareja2.png"))); // NOI18N
        jPanel4.add(jLabel61);
        jLabel61.setBounds(30, 10, 40, 40);

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("SELECCIONA LOS BOLETOS");
        jPanel4.add(jLabel3);
        jLabel3.setBounds(74, 12, 304, 31);

        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("BOLETOS PARA ADULTOS:");
        jPanel4.add(jLabel4);
        jLabel4.setBounds(70, 60, 213, 23);

        jSpinnerBoletoAdulto.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jSpinnerBoletoAdulto.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        jPanel4.add(jSpinnerBoletoAdulto);
        jSpinnerBoletoAdulto.setBounds(290, 60, 76, 28);

        jLabel5.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("BOLETOS PARA ADULTO MAYOR:");
        jPanel4.add(jLabel5);
        jLabel5.setBounds(10, 110, 274, 23);

        jLabel68.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 255, 255));
        jLabel68.setText("PELÍCULA:");
        jPanel4.add(jLabel68);
        jLabel68.setBounds(10, 250, 60, 23);

        jLabel65.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 255, 255));
        jLabel65.setText("PRECIO TOTAL POR BOLETOS: $");
        jPanel4.add(jLabel65);
        jLabel65.setBounds(10, 230, 180, 23);

        jLabelPeliculaNombre.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabelPeliculaNombre.setForeground(new java.awt.Color(255, 255, 255));
        jPanel4.add(jLabelPeliculaNombre);
        jLabelPeliculaNombre.setBounds(70, 250, 280, 23);

        jLabelPRECIOTOTALBOLETOS.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabelPRECIOTOTALBOLETOS.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPRECIOTOTALBOLETOS.setText("0.00");
        jPanel4.add(jLabelPRECIOTOTALBOLETOS);
        jLabelPRECIOTOTALBOLETOS.setBounds(190, 230, 80, 23);

        jLabelPRECIO.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabelPRECIO.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPRECIO.setText("0");
        jPanel4.add(jLabelPRECIO);
        jLabelPRECIO.setBounds(130, 210, 80, 20);

        jLabel64.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setText("TOTAL DE BOLETOS:");
        jPanel4.add(jLabel64);
        jLabel64.setBounds(10, 210, 109, 16);

        jSpinnerBoletoAdultoMAyor.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jSpinnerBoletoAdultoMAyor.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        jPanel4.add(jSpinnerBoletoAdultoMAyor);
        jSpinnerBoletoAdultoMAyor.setBounds(290, 110, 76, 28);

        jLabel6.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("BOLETOS PARA NIÑOS:");
        jPanel4.add(jLabel6);
        jLabel6.setBounds(90, 160, 190, 23);

        jSpinnerBoletoÑino.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jSpinnerBoletoÑino.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));
        jPanel4.add(jSpinnerBoletoÑino);
        jSpinnerBoletoÑino.setBounds(290, 160, 76, 28);

        jLabel60.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/fondo-degradado-azul.jpg"))); // NOI18N
        jPanel4.add(jLabel60);
        jLabel60.setBounds(0, 0, 390, 280);

        jDesktopPane5.add(jPanel4);
        jPanel4.setBounds(40, 33, 390, 280);

        jLabelBusquedaImplacable.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/BusquedaImplacable.jpg"))); // NOI18N
        jLabelBusquedaImplacable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelBusquedaImplacableMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelBusquedaImplacable);
        jLabelBusquedaImplacable.setBounds(899, 83, 130, 186);

        jLabelEndGame.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/EndGame.jpg"))); // NOI18N
        jLabelEndGame.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelEndGameMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelEndGame);
        jLabelEndGame.setBounds(447, 83, 130, 186);

        jLabelDeadPool.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/DeadPool2.jpg"))); // NOI18N
        jLabelDeadPool.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDeadPoolMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelDeadPool);
        jLabelDeadPool.setBounds(664, 83, 130, 186);

        jLabelDumbo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Dumbo.jpg"))); // NOI18N
        jLabelDumbo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDumboMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelDumbo);
        jLabelDumbo.setBounds(255, 325, 130, 186);

        jLabelMoana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Moana.jpg"))); // NOI18N
        jLabelMoana.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMoanaMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelMoana);
        jLabelMoana.setBounds(447, 325, 140, 186);

        jLabelPixeles.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Pixeles.jpg"))); // NOI18N
        jLabelPixeles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelPixelesMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelPixeles);
        jLabelPixeles.setBounds(50, 325, 130, 186);

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("¿QUE PELÍCULA QUE DESEAS VER?");
        jDesktopPane5.add(jLabel7);
        jLabel7.setBounds(450, 20, 580, 45);

        jLabelFrozen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Frozen2.jpg"))); // NOI18N
        jLabelFrozen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelFrozenMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelFrozen);
        jLabelFrozen.setBounds(664, 325, 139, 186);

        jLabelKungFuPanda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/KungFuPanda1.jpg"))); // NOI18N
        jLabelKungFuPanda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelKungFuPandaMouseClicked(evt);
            }
        });
        jDesktopPane5.add(jLabelKungFuPanda);
        jLabelKungFuPanda.setBounds(899, 325, 124, 186);

        lblAVtexto.setText("avengers: endgame");
        jDesktopPane5.add(lblAVtexto);
        lblAVtexto.setBounds(450, 90, 96, 15);

        lblDeadTexto.setText("deadpool 2");
        jDesktopPane5.add(lblDeadTexto);
        lblDeadTexto.setBounds(670, 90, 53, 15);

        bllBusquedaTexto.setText("busqueda implacable");
        jDesktopPane5.add(bllBusquedaTexto);
        bllBusquedaTexto.setBounds(910, 100, 40, 15);

        lblPixelsTexto.setText("pixels");
        jDesktopPane5.add(lblPixelsTexto);
        lblPixelsTexto.setBounds(60, 340, 28, 15);

        lblDumboTexto.setText("dumbo");
        jDesktopPane5.add(lblDumboTexto);
        lblDumboTexto.setBounds(270, 340, 32, 15);

        lblMoanaTexto.setText("moana");
        jDesktopPane5.add(lblMoanaTexto);
        lblMoanaTexto.setBounds(470, 340, 80, 40);

        lblFrozenTexto.setText("Frozen 2");
        jDesktopPane5.add(lblFrozenTexto);
        lblFrozenTexto.setBounds(720, 360, 40, 15);

        lblKFPTexto.setText("kung fu panda");
        jDesktopPane5.add(lblKFPTexto);
        lblKFPTexto.setBounds(920, 410, 40, 15);

        javax.swing.GroupLayout jPanDESPACHO_BOLETOSLayout = new javax.swing.GroupLayout(jPanDESPACHO_BOLETOS);
        jPanDESPACHO_BOLETOS.setLayout(jPanDESPACHO_BOLETOSLayout);
        jPanDESPACHO_BOLETOSLayout.setHorizontalGroup(
            jPanDESPACHO_BOLETOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane5, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanDESPACHO_BOLETOSLayout.setVerticalGroup(
            jPanDESPACHO_BOLETOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane5)
        );

        TabbedMainPane.addTab("DESPACHO DE BOLETOS", jPanDESPACHO_BOLETOS);

        jDesktopPane2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel2.setText("ESCOGE UNA SALA:");

        jLabel54.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel54.setText("ESCOGE LA FUNCION:");

        jComboBoxSALAS.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jComboBoxSALAS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SALA DOBLADA", "SALA 3D DOBLADA", "SALA SUBTITULADA", "SALA 3D SUBTITULADA" }));

        jComboBoxFUNCIONES.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jComboBoxFUNCIONES.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "HORA    12:15HRS", "HORA    13:30HRS", "HORA    15:45HRS", "HORA    17:30HRS", "HORA     22:30HRS", "HORA     00:00HRS" }));

        jButtonSIGUIENTE.setBackground(new java.awt.Color(51, 51, 255));
        jButtonSIGUIENTE.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jButtonSIGUIENTE.setForeground(new java.awt.Color(255, 255, 255));
        jButtonSIGUIENTE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/entradas-de-cine-para-una-pareja2.png"))); // NOI18N
        jButtonSIGUIENTE.setText("¡Selecciona sala, función, asientos y hazme clic!");
        jButtonSIGUIENTE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSIGUIENTEActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(6, 6, 6)
                .addComponent(jComboBoxSALAS, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(jButtonSIGUIENTE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(3, 3, 3)
                .addComponent(jLabel54)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBoxFUNCIONES, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonSIGUIENTE, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxSALAS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel54)
                    .addComponent(jComboBoxFUNCIONES, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 19, Short.MAX_VALUE))
        );

        jDesktopPane2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-1, 529, 1070, 50));

        jButtonAsientoA2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA2MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA2MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA2, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 421, -1, -1));

        jButtonAsientoA1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA1MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA1, new org.netbeans.lib.awtextra.AbsoluteConstraints(79, 421, -1, -1));

        jButtonAsientoA3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA3MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA3MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA3, new org.netbeans.lib.awtextra.AbsoluteConstraints(271, 421, -1, -1));

        jButtonAsientoA4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA4MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA4MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA4, new org.netbeans.lib.awtextra.AbsoluteConstraints(361, 421, -1, -1));

        jButtonAsientoA5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA5MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA5MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA5, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 421, -1, -1));

        jButtonAsientoA6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA6MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA6MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA6, new org.netbeans.lib.awtextra.AbsoluteConstraints(553, 421, -1, -1));

        jButtonAsientoA8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA8MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA8MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA8, new org.netbeans.lib.awtextra.AbsoluteConstraints(745, 421, -1, -1));

        jButtonAsientoA7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA7MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA7MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA7, new org.netbeans.lib.awtextra.AbsoluteConstraints(649, 421, -1, -1));

        jButtonAsientoA9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA9MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoA9MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA9, new org.netbeans.lib.awtextra.AbsoluteConstraints(841, 421, -1, -1));

        jButtonAsientoA10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoA10.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButtonAsientoA10MouseMoved(evt);
            }
        });
        jButtonAsientoA10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoA10MouseClicked(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoA10, new org.netbeans.lib.awtextra.AbsoluteConstraints(937, 421, -1, -1));

        jButtonAsientoB1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB1MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(79, 300, -1, -1));

        jButtonAsientoB2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB2MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB2MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB2, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 300, -1, -1));

        jButtonAsientoB3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB3MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB3MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB3, new org.netbeans.lib.awtextra.AbsoluteConstraints(271, 300, -1, -1));

        jButtonAsientoB4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB4MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB4MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB4, new org.netbeans.lib.awtextra.AbsoluteConstraints(361, 300, -1, -1));

        jButtonAsientoB5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB5MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB5MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB5, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 300, -1, -1));

        jButtonAsientoB6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB6MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB6MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB6, new org.netbeans.lib.awtextra.AbsoluteConstraints(553, 300, -1, -1));

        jButtonAsientoB7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB7MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB7MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB7, new org.netbeans.lib.awtextra.AbsoluteConstraints(649, 300, -1, -1));

        jButtonAsientoB8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB8MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB8MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB8, new org.netbeans.lib.awtextra.AbsoluteConstraints(745, 300, -1, -1));

        jButtonAsientoB9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB9MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB9MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB9, new org.netbeans.lib.awtextra.AbsoluteConstraints(841, 300, -1, -1));

        jButtonAsientoB10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoB10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoB10MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoB10MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoB10, new org.netbeans.lib.awtextra.AbsoluteConstraints(937, 300, -1, -1));

        jButtonAsientoD1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD1MousePressed(evt);
            }
        });
        jButtonAsientoD1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAsientoD1ActionPerformed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD1, new org.netbeans.lib.awtextra.AbsoluteConstraints(79, 57, -1, -1));

        jButtonAsientoD8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD8MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD8MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD8, new org.netbeans.lib.awtextra.AbsoluteConstraints(745, 57, -1, -1));

        jButtonAsientoD5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD5MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD5MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD5, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 57, -1, -1));

        jButtonAsientoD4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD4MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD4MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD4, new org.netbeans.lib.awtextra.AbsoluteConstraints(361, 57, -1, -1));

        jButtonAsientoD3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD3MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD3MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD3, new org.netbeans.lib.awtextra.AbsoluteConstraints(271, 57, -1, -1));

        jButtonAsientoD6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD6MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD6MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD6, new org.netbeans.lib.awtextra.AbsoluteConstraints(553, 57, -1, -1));

        jButtonAsientoD9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD9MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD9MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD9, new org.netbeans.lib.awtextra.AbsoluteConstraints(841, 57, -1, -1));

        jButtonAsientoD7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD7MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD7MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD7, new org.netbeans.lib.awtextra.AbsoluteConstraints(649, 57, -1, -1));

        jButtonAsientoD2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD2MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD2MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD2, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 57, -1, -1));

        jButtonAsientoD10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoD10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoD10MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoD10MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoD10, new org.netbeans.lib.awtextra.AbsoluteConstraints(937, 57, -1, -1));

        jButtonAsientoC1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC1MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC1, new org.netbeans.lib.awtextra.AbsoluteConstraints(79, 178, -1, -1));

        jButtonAsientoC2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC2MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC2MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC2, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 178, -1, -1));

        jButtonAsientoC3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC3MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC3MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC3, new org.netbeans.lib.awtextra.AbsoluteConstraints(271, 178, -1, -1));

        jButtonAsientoC4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC4MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC4MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC4, new org.netbeans.lib.awtextra.AbsoluteConstraints(361, 178, -1, -1));

        jButtonAsientoC5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC5MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC5MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC5, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 178, -1, -1));

        jButtonAsientoC6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC6MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC6MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC6, new org.netbeans.lib.awtextra.AbsoluteConstraints(553, 178, -1, -1));

        jButtonAsientoC7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC7MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC7MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC7, new org.netbeans.lib.awtextra.AbsoluteConstraints(649, 178, -1, -1));

        jButtonAsientoC8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC8MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC8MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC8, new org.netbeans.lib.awtextra.AbsoluteConstraints(745, 178, -1, -1));

        jButtonAsientoC9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC9MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC9MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC9, new org.netbeans.lib.awtextra.AbsoluteConstraints(841, 178, -1, -1));

        jButtonAsientoC10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_travel-tourism-vacation-holiday-25_4049292.png"))); // NOI18N
        jButtonAsientoC10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonAsientoC10MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonAsientoC10MousePressed(evt);
            }
        });
        jDesktopPane2.add(jButtonAsientoC10, new org.netbeans.lib.awtextra.AbsoluteConstraints(937, 178, -1, -1));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("A");
        jDesktopPane2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(64, 431, -1, -1));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("B");
        jDesktopPane2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 318, -1, -1));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("D");
        jDesktopPane2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 74, -1, -1));

        jLabel11.setText(" ");
        jDesktopPane2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 226, -1, -1));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("1");
        jDesktopPane2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 127, -1, -1));

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("2");
        jDesktopPane2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 127, -1, -1));

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("4");
        jDesktopPane2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 127, -1, -1));

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("3");
        jDesktopPane2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(294, 127, -1, -1));

        jLabel16.setBackground(new java.awt.Color(255, 255, 255));
        jLabel16.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("6");
        jDesktopPane2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(578, 127, -1, -1));

        jLabel17.setBackground(new java.awt.Color(255, 255, 255));
        jLabel17.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("5");
        jDesktopPane2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(483, 127, -1, -1));

        jLabel18.setBackground(new java.awt.Color(255, 255, 255));
        jLabel18.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("8");
        jDesktopPane2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(768, 127, -1, -1));

        jLabel19.setBackground(new java.awt.Color(255, 255, 255));
        jLabel19.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("7");
        jDesktopPane2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(673, 127, -1, -1));

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("10");
        jDesktopPane2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(968, 127, -1, -1));

        jLabel21.setBackground(new java.awt.Color(255, 255, 255));
        jLabel21.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("9");
        jDesktopPane2.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(866, 127, -1, -1));

        jLabel22.setBackground(new java.awt.Color(255, 255, 255));
        jLabel22.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("1");
        jDesktopPane2.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 248, -1, -1));

        jLabel23.setBackground(new java.awt.Color(255, 255, 255));
        jLabel23.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("2");
        jDesktopPane2.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(201, 248, -1, -1));

        jLabel24.setBackground(new java.awt.Color(255, 255, 255));
        jLabel24.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("3");
        jDesktopPane2.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(299, 248, -1, -1));

        jLabel25.setBackground(new java.awt.Color(255, 255, 255));
        jLabel25.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("4");
        jDesktopPane2.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(394, 248, -1, -1));

        jLabel26.setBackground(new java.awt.Color(255, 255, 255));
        jLabel26.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("5");
        jDesktopPane2.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(488, 248, -1, -1));

        jLabel27.setBackground(new java.awt.Color(255, 255, 255));
        jLabel27.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("6");
        jDesktopPane2.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(583, 248, -1, -1));

        jLabel28.setBackground(new java.awt.Color(255, 255, 255));
        jLabel28.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("7");
        jDesktopPane2.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(678, 248, -1, -1));

        jLabel29.setBackground(new java.awt.Color(255, 255, 255));
        jLabel29.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("8");
        jDesktopPane2.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(773, 248, -1, -1));

        jLabel30.setBackground(new java.awt.Color(255, 255, 255));
        jLabel30.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("9");
        jDesktopPane2.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(871, 248, -1, -1));

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("10");
        jDesktopPane2.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(966, 248, -1, -1));

        jLabel32.setBackground(new java.awt.Color(255, 255, 255));
        jLabel32.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("10");
        jDesktopPane2.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(967, 370, -1, -1));

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("3");
        jDesktopPane2.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 370, -1, -1));

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("4");
        jDesktopPane2.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(395, 370, -1, -1));

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("9");
        jDesktopPane2.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(872, 370, -1, -1));

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("2");
        jDesktopPane2.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(202, 370, -1, -1));

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("5");
        jDesktopPane2.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(489, 370, -1, -1));

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("8");
        jDesktopPane2.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(774, 370, -1, -1));

        jLabel39.setBackground(new java.awt.Color(255, 255, 255));
        jLabel39.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("1");
        jDesktopPane2.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 370, -1, -1));

        jLabel40.setBackground(new java.awt.Color(255, 255, 255));
        jLabel40.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("6");
        jDesktopPane2.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(584, 370, -1, -1));

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("7");
        jDesktopPane2.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(679, 370, -1, -1));

        jLabel42.setBackground(new java.awt.Color(255, 255, 255));
        jLabel42.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("1");
        jDesktopPane2.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(105, 491, -1, -1));

        jLabel43.setBackground(new java.awt.Color(255, 255, 255));
        jLabel43.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("7");
        jDesktopPane2.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(677, 491, -1, -1));

        jLabel44.setBackground(new java.awt.Color(255, 255, 255));
        jLabel44.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("2");
        jDesktopPane2.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 491, -1, -1));

        jLabel45.setBackground(new java.awt.Color(255, 255, 255));
        jLabel45.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("4");
        jDesktopPane2.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 491, -1, -1));

        jLabel46.setBackground(new java.awt.Color(255, 255, 255));
        jLabel46.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("10");
        jDesktopPane2.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(965, 491, -1, -1));

        jLabel47.setBackground(new java.awt.Color(255, 255, 255));
        jLabel47.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("5");
        jDesktopPane2.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(487, 491, -1, -1));

        jLabel48.setBackground(new java.awt.Color(255, 255, 255));
        jLabel48.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("6");
        jDesktopPane2.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(582, 491, -1, -1));

        jLabel49.setBackground(new java.awt.Color(255, 255, 255));
        jLabel49.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setText("8");
        jDesktopPane2.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(772, 491, -1, -1));

        jLabel50.setBackground(new java.awt.Color(255, 255, 255));
        jLabel50.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.setText("9");
        jDesktopPane2.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 491, -1, -1));

        jLabel51.setBackground(new java.awt.Color(255, 255, 255));
        jLabel51.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 255, 255));
        jLabel51.setText("3");
        jDesktopPane2.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(298, 491, -1, -1));

        jLabel52.setBackground(new java.awt.Color(255, 255, 255));
        jLabel52.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setText("¿EN DÓNDE DESEAS SENTARTE?");
        jDesktopPane2.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, -1, -1));

        jLabel53.setBackground(new java.awt.Color(255, 255, 255));
        jLabel53.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 255, 255));
        jLabel53.setText("C");
        jDesktopPane2.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 203, -1, -1));

        javax.swing.GroupLayout jPanESCOGER_SALALayout = new javax.swing.GroupLayout(jPanESCOGER_SALA);
        jPanESCOGER_SALA.setLayout(jPanESCOGER_SALALayout);
        jPanESCOGER_SALALayout.setHorizontalGroup(
            jPanESCOGER_SALALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1057, Short.MAX_VALUE)
        );
        jPanESCOGER_SALALayout.setVerticalGroup(
            jPanESCOGER_SALALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
        );

        TabbedMainPane.addTab("ESCOGER SALA/ASIENTO", jPanESCOGER_SALA);

        jDesktopPane3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButtonSoda.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jButtonSoda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/soda.png"))); // NOI18N
        jButtonSoda.setText("SODAS $2.50");
        jButtonSoda.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonSoda.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jButtonSoda.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonSoda.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jButtonSodaStateChanged(evt);
            }
        });
        jButtonSoda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSodaActionPerformed(evt);
            }
        });
        jDesktopPane3.add(jButtonSoda, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 220, 160));

        jButtonPalomitasMedianas.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jButtonPalomitasMedianas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/32396popcorn_98852.png"))); // NOI18N
        jButtonPalomitasMedianas.setText("PALOMITAS MEDIANAS $1.50");
        jButtonPalomitasMedianas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonPalomitasMedianas.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jButtonPalomitasMedianas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonPalomitasMedianas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPalomitasMedianasActionPerformed(evt);
            }
        });
        jDesktopPane3.add(jButtonPalomitasMedianas, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 100, -1, 160));

        jButtonHotDogs.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jButtonHotDogs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/foodhotdog_122748.png"))); // NOI18N
        jButtonHotDogs.setText("HOTDOGS $1.00");
        jButtonHotDogs.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHotDogs.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jButtonHotDogs.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHotDogs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHotDogsActionPerformed(evt);
            }
        });
        jDesktopPane3.add(jButtonHotDogs, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 100, 220, 160));

        jButtonPalomitasGrandes.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jButtonPalomitasGrandes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/32396popcorn_98852.png"))); // NOI18N
        jButtonPalomitasGrandes.setText("PALOMITAS GRANDES $3.00");
        jButtonPalomitasGrandes.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonPalomitasGrandes.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jButtonPalomitasGrandes.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonPalomitasGrandes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPalomitasGrandesActionPerformed(evt);
            }
        });
        jDesktopPane3.add(jButtonPalomitasGrandes, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 100, -1, 160));

        jLabel55.setBackground(new java.awt.Color(255, 255, 255));
        jLabel55.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setText("¿QUE SE TE ANTOJA HOY?");
        jDesktopPane3.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, -1, -1));

        jLabelCUANTASODAS.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCUANTASODAS.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCUANTASODAS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCUANTASODAS.setText("¿CUÁNTAS?");
        jDesktopPane3.add(jLabelCUANTASODAS, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 160, 20));

        jLabelINDICACIONES.setFont(new java.awt.Font("Century Gothic", 3, 24)); // NOI18N
        jLabelINDICACIONES.setForeground(new java.awt.Color(102, 51, 255));
        jLabelINDICACIONES.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelINDICACIONES.setText("<html><center>Una pequeña indicación de Cine AWLAMA <p>[ OJO: ¡Desliza en el spinner, luego clic en la comida que deseas y presiona CONFIRMAR! ]</center></p></html>");
        jDesktopPane3.add(jLabelINDICACIONES, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 470, 1000, 100));

        jSpinnerPALOMITASM.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jSpinnerPALOMITASM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 5, 1));
        jDesktopPane3.add(jSpinnerPALOMITASM, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 270, 56, -1));

        jSpinnerHOTDOGS.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jSpinnerHOTDOGS.setModel(new javax.swing.SpinnerNumberModel(0, 0, 5, 1));
        jDesktopPane3.add(jSpinnerHOTDOGS, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 270, 56, -1));

        jLabelCUANTAHOTDOG.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCUANTAHOTDOG.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCUANTAHOTDOG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCUANTAHOTDOG.setText("¿CUÁNTOS?");
        jDesktopPane3.add(jLabelCUANTAHOTDOG, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 270, 160, 20));

        jLabelCUANTASPALIMITASG.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCUANTASPALIMITASG.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCUANTASPALIMITASG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCUANTASPALIMITASG.setText("¿CUÁNTAS?");
        jDesktopPane3.add(jLabelCUANTASPALIMITASG, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 270, 160, 20));

        jSpinnerPALOMITASG.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jSpinnerPALOMITASG.setModel(new javax.swing.SpinnerNumberModel(0, 0, 5, 1));
        jDesktopPane3.add(jSpinnerPALOMITASG, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 270, 56, -1));

        jButtonCONFORMAR_GOLOSINAS.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jButtonCONFORMAR_GOLOSINAS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Good_or_Tick_36889.png"))); // NOI18N
        jButtonCONFORMAR_GOLOSINAS.setText("CONFIRMAR");
        jButtonCONFORMAR_GOLOSINAS.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCONFORMAR_GOLOSINAS.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCONFORMAR_GOLOSINAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCONFORMAR_GOLOSINASActionPerformed(evt);
            }
        });
        jDesktopPane3.add(jButtonCONFORMAR_GOLOSINAS, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 1000, 110));

        jSpinnerSODA.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jSpinnerSODA.setModel(new javax.swing.SpinnerNumberModel(0, 0, 5, 1));
        jDesktopPane3.add(jSpinnerSODA, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, 60, -1));

        jLabelCUANTASPALOMITASM1.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCUANTASPALOMITASM1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCUANTASPALOMITASM1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCUANTASPALOMITASM1.setText("¿CUÁNTAS?");
        jDesktopPane3.add(jLabelCUANTASPALOMITASM1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 270, 170, 20));

        lblIndicacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/degradado-azul.jpg"))); // NOI18N
        jDesktopPane3.add(lblIndicacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 470, 1000, 100));

        lblSodaTexto.setText("SODA");
        jDesktopPane3.add(lblSodaTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 40, 50));

        lblPalomitasMTexto.setText("PALOMITAS MEDIANAS");
        jDesktopPane3.add(lblPalomitasMTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 130, 70));

        lblHotDogsTexto.setText("HOT DOGS");
        jDesktopPane3.add(lblHotDogsTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 170, 60, 30));

        lblPalomitasGTexto.setText("PALOMITAS GRANDES");
        jDesktopPane3.add(lblPalomitasGTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 160, -1, 40));

        javax.swing.GroupLayout jPanESCOGER_GOLOSINASLayout = new javax.swing.GroupLayout(jPanESCOGER_GOLOSINAS);
        jPanESCOGER_GOLOSINAS.setLayout(jPanESCOGER_GOLOSINASLayout);
        jPanESCOGER_GOLOSINASLayout.setHorizontalGroup(
            jPanESCOGER_GOLOSINASLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1060, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanESCOGER_GOLOSINASLayout.setVerticalGroup(
            jPanESCOGER_GOLOSINASLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        TabbedMainPane.addTab("ESCOGER GOLOSINAS", jPanESCOGER_GOLOSINAS);

        jTablePELICULAS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PELÍCULA", "BOLETOS ADULTO", "BOLETOS ADULTO MAYOR", "BOLETOS NIÑO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTablePELICULAS);

        jTableCOMIDA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRODUCTO", "CANTIDAD", "PRECIO/U", "TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTableCOMIDA);

        jTableSALA_ASIENTOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "SALA", "HORARIO", "ASIENTOS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTableSALA_ASIENTOS);

        jDesktopPane6.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane6.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane6.setLayer(jScrollPane3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane6Layout = new javax.swing.GroupLayout(jDesktopPane6);
        jDesktopPane6.setLayout(jDesktopPane6Layout);
        jDesktopPane6Layout.setHorizontalGroup(
            jDesktopPane6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane6Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1030, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jDesktopPane6Layout.setVerticalGroup(
            jDesktopPane6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane6Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jDesktopPane6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(80, 80, 80)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jLabel56.setBackground(new java.awt.Color(255, 255, 255));
        jLabel56.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 255, 255));
        jLabel56.setText("DATOS DE TU RESERVACION");

        jLabel58.setBackground(new java.awt.Color(255, 255, 255));
        jLabel58.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText("DATOS DE TU PEDIDO DE GOLOSINAS");

        jLabel62.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel62.setText("TOTAL POR GOLOSINAS: $");

        txtTotalPorGolosinas.setEditable(false);
        txtTotalPorGolosinas.setFont(new java.awt.Font("Century Gothic", 3, 18)); // NOI18N
        txtTotalPorGolosinas.setForeground(new java.awt.Color(0, 0, 255));
        txtTotalPorGolosinas.setText("0.0");
        txtTotalPorGolosinas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalPorGolosinasActionPerformed(evt);
            }
        });

        jLabel66.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel66.setText("TOTAL GENERAL: $");

        txtTotalPagar.setEditable(false);
        txtTotalPagar.setFont(new java.awt.Font("Century Gothic", 3, 18)); // NOI18N
        txtTotalPagar.setForeground(new java.awt.Color(0, 0, 255));
        txtTotalPagar.setText("0.0");
        txtTotalPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalPagarActionPerformed(evt);
            }
        });

        jDesktopPane4.setLayer(jDesktopPane6, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane4.setLayer(jLabel56, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane4.setLayer(jLabel58, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane4.setLayer(jLabel62, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane4.setLayer(txtTotalPorGolosinas, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane4.setLayer(jLabel66, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane4.setLayer(txtTotalPagar, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane4Layout = new javax.swing.GroupLayout(jDesktopPane4);
        jDesktopPane4.setLayout(jDesktopPane4Layout);
        jDesktopPane4Layout.setHorizontalGroup(
            jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDesktopPane4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel56)
                .addGap(250, 250, 250))
            .addGroup(jDesktopPane4Layout.createSequentialGroup()
                .addGroup(jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane4Layout.createSequentialGroup()
                        .addGap(259, 259, 259)
                        .addComponent(jLabel58)
                        .addGap(0, 157, Short.MAX_VALUE))
                    .addGroup(jDesktopPane4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel62)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTotalPorGolosinas, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel66)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTotalPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jDesktopPane4Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jDesktopPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jDesktopPane4Layout.setVerticalGroup(
            jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel56)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 226, Short.MAX_VALUE)
                .addComponent(jLabel58)
                .addGap(208, 208, 208)
                .addGroup(jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel66)
                        .addComponent(txtTotalPagar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel62)
                        .addComponent(txtTotalPorGolosinas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jDesktopPane4Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jDesktopPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanDETALLE_VENTALayout = new javax.swing.GroupLayout(jPanDETALLE_VENTA);
        jPanDETALLE_VENTA.setLayout(jPanDETALLE_VENTALayout);
        jPanDETALLE_VENTALayout.setHorizontalGroup(
            jPanDETALLE_VENTALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane4)
        );
        jPanDETALLE_VENTALayout.setVerticalGroup(
            jPanDETALLE_VENTALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane4)
        );

        TabbedMainPane.addTab("DETALLE DE VENTA", jPanDETALLE_VENTA);

        jDesktopPane7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jDesktopPane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButtonTARJETA_VISA.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jButtonTARJETA_VISA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/1495815246-jd01_84592.png"))); // NOI18N
        jButtonTARJETA_VISA.setText("TARJETA DE CRÉDITO/DEBITO");
        jButtonTARJETA_VISA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTARJETA_VISAActionPerformed(evt);
            }
        });
        jDesktopPane1.add(jButtonTARJETA_VISA, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, 80));

        jButtonPAYPAL.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jButtonPAYPAL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/paypal.png"))); // NOI18N
        jButtonPAYPAL.setText("PAY-PAL");
        jButtonPAYPAL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPAYPALActionPerformed(evt);
            }
        });
        jDesktopPane1.add(jButtonPAYPAL, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 80, -1, 80));

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelCLUB_NOMBRE.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCLUB_NOMBRE.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCLUB_NOMBRE.setText("NOMBRE COMPLETO: ");
        jPanel6.add(jLabelCLUB_NOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        jTextFieldVISA_NOMBRE.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jTextFieldVISA_NOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 290, 30));

        jLabelCLUB_DUI.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCLUB_DUI.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCLUB_DUI.setText("DUI:");
        jPanel6.add(jLabelCLUB_DUI, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 50, -1, -1));

        jTextFieldVISA_DUI.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jTextFieldVISA_DUI, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 60, 241, 30));

        jLabelCLUB_NUMTARJETA.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCLUB_NUMTARJETA.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCLUB_NUMTARJETA.setText("NUMERO DE TARJETA CLUB:");
        jPanel6.add(jLabelCLUB_NUMTARJETA, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, 20));

        jTextFieldVISA_NUMTARJETA.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jTextFieldVISA_NUMTARJETA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 600, -1));

        jTextFieldCLUB_NUMTARJETA.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jTextFieldCLUB_NUMTARJETA, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 560, 30));

        jTextFieldCLUB_NOMBRE.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jTextFieldCLUB_NOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 290, 30));

        jLabelContraseniaPago.setBackground(new java.awt.Color(255, 255, 255));
        jLabelContraseniaPago.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelContraseniaPago.setText("CONTRASEÑA:");
        jPanel6.add(jLabelContraseniaPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabelVISA_NOMBRE.setBackground(new java.awt.Color(255, 255, 255));
        jLabelVISA_NOMBRE.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelVISA_NOMBRE.setText("NOMBRE COMPLETO: ");
        jPanel6.add(jLabelVISA_NOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        jLabelVISA_DUI.setBackground(new java.awt.Color(255, 255, 255));
        jLabelVISA_DUI.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelVISA_DUI.setText("DUI:");
        jPanel6.add(jLabelVISA_DUI, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 70, -1, -1));

        jTextFieldCLUB_DUI.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jTextFieldCLUB_DUI, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 240, 30));

        jPasswordField1.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 650, -1));

        jLabelCorreo.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCorreo.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelCorreo.setText("CORREO:");
        jPanel6.add(jLabelCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, -1, -1));

        jTextFieldCorreo.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        jPanel6.add(jTextFieldCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 650, 30));

        jLabelVISA_NUMTARJETA.setBackground(new java.awt.Color(255, 255, 255));
        jLabelVISA_NUMTARJETA.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabelVISA_NUMTARJETA.setText("NUMERO DE TARJETA:");
        jPanel6.add(jLabelVISA_NUMTARJETA, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jButtonSALIR.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jButtonSALIR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/gafas-3d.png"))); // NOI18N
        jButtonSALIR.setText("¡DISFRUTA!");
        jButtonSALIR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonSALIR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonSALIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSALIRActionPerformed(evt);
            }
        });
        jPanel6.add(jButtonSALIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 50, 170, -1));

        jLabel67.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/degradado-morado.jpg"))); // NOI18N
        jPanel6.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 180));

        jDesktopPane1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 202, 1000, 180));

        jLabel57.setBackground(new java.awt.Color(255, 255, 255));
        jLabel57.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("¿CÓMO DESEAS PAGAR?");
        jDesktopPane1.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(381, 6, -1, -1));

        btnPDF.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        btnPDF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_icon-70-document-file-pdf_315274.png"))); // NOI18N
        btnPDF.setText("GENERAR FACTURA");
        btnPDF.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPDF.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnPDF.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });
        jDesktopPane1.add(btnPDF, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 442, 1010, 110));

        jButtonTARJETA_CLUB.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jButtonTARJETA_CLUB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/card_115200_1.png"))); // NOI18N
        jButtonTARJETA_CLUB.setText("   TARJETA CLUB CINE-AWLAMA");
        jButtonTARJETA_CLUB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTARJETA_CLUBActionPerformed(evt);
            }
        });
        jDesktopPane1.add(jButtonTARJETA_CLUB, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, -1, 80));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane4.setViewportView(jTextArea1);

        jDesktopPane1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 440, 200, 0));

        javax.swing.GroupLayout jPanMETODOS_PAGOLayout = new javax.swing.GroupLayout(jPanMETODOS_PAGO);
        jPanMETODOS_PAGO.setLayout(jPanMETODOS_PAGOLayout);
        jPanMETODOS_PAGOLayout.setHorizontalGroup(
            jPanMETODOS_PAGOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanMETODOS_PAGOLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jDesktopPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanMETODOS_PAGOLayout.setVerticalGroup(
            jPanMETODOS_PAGOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanMETODOS_PAGOLayout.createSequentialGroup()
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jDesktopPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        TabbedMainPane.addTab("METODOS DE PAGO", jPanMETODOS_PAGO);

        getContentPane().add(TabbedMainPane);
        TabbedMainPane.setBounds(0, 160, 1250, 580);

        jLabel59.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/PNG.png"))); // NOI18N
        getContentPane().add(jLabel59);
        jLabel59.setBounds(190, 0, 920, 160);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/sala-cine.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1430, 770);

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 255));
        jMenuBar1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jMenuBar1.setForeground(new java.awt.Color(0, 0, 0));

        jMenuInicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_Home_1214974.png"))); // NOI18N
        jMenuInicio.setText("INICIO");
        jMenuInicio.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jMenuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuInicioActionPerformed(evt);
            }
        });

        jMenuItem8.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jMenuItem8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/iconfinder_exit-enter-leave-in-door_2931187.png"))); // NOI18N
        jMenuItem8.setText("SALIR");
        jMenuItem8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem8MouseClicked(evt);
            }
        });
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenuInicio.add(jMenuItem8);

        jMenuBar1.add(jMenuInicio);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuInicioActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuInicioActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem8MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jMenuItem8MouseClicked

    private void jButtonPalomitasMedianasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPalomitasMedianasActionPerformed
        Clases.Golosinas peli = new Clases.Golosinas("Soda", "Palomitas Medianas", "Hot Dog", "Palomitas Grandes");
        double pPalomitasM = 1.50;
        String p = Double.toString(pPalomitasM);
        String[] registro = {peli.getPalomitasMedianas().toUpperCase(), this.jSpinnerPALOMITASM.getValue().toString(), p, Double.toString((pPalomitasM * Double.parseDouble(this.jSpinnerPALOMITASM.getValue().toString())))};

        modeloComida.addRow(registro);
        this.txtTotalPorGolosinas.setText(Double.toString(TotalPagarGolosinas()));
        this.txtTotalPagar.setText(Double.toString(TotalPagarPagar()));
        
        this.jSpinnerPALOMITASM.setVisible(true);
        this.jLabelINDICACIONES.setVisible(true);
    }//GEN-LAST:event_jButtonPalomitasMedianasActionPerformed

    private void jButtonPalomitasGrandesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPalomitasGrandesActionPerformed
        Clases.Golosinas peli = new Clases.Golosinas("Soda", "Palomitas Medianas", "Hot Dog", "Palomitas Grandes");
        double pPalomitasG = 3.00;
        String p = Double.toString(pPalomitasG);
        String[] registro = {peli.getPalomitasGrandes().toUpperCase(), this.jSpinnerPALOMITASG.getValue().toString(), p, Double.toString((pPalomitasG * Double.parseDouble(this.jSpinnerPALOMITASG.getValue().toString())))};

        modeloComida.addRow(registro);
        this.txtTotalPorGolosinas.setText(Double.toString(TotalPagarGolosinas()));
        this.txtTotalPagar.setText(Double.toString(TotalPagarPagar()));

        this.jSpinnerPALOMITASG.setVisible(true);
        this.jLabelCUANTASPALIMITASG.setVisible(true);
    }//GEN-LAST:event_jButtonPalomitasGrandesActionPerformed

    private void jButtonHotDogsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHotDogsActionPerformed
        Clases.Golosinas peli = new Clases.Golosinas("Soda", "Palomitas Medianas", "Hot Dog", "Palomitas Grandes");
        double pHotDog = 1.00;
        String p = Double.toString(pHotDog);
        String[] registro = {peli.getHotDogs().toUpperCase(), this.jSpinnerHOTDOGS.getValue().toString(), p, Double.toString((pHotDog * Double.parseDouble(this.jSpinnerHOTDOGS.getValue().toString())))};

        modeloComida.addRow(registro);
        this.txtTotalPorGolosinas.setText(Double.toString(TotalPagarGolosinas()));
        this.txtTotalPagar.setText(Double.toString(TotalPagarPagar()));

        this.jSpinnerHOTDOGS.setVisible(true);
        this.jLabelCUANTAHOTDOG.setVisible(true);
    }//GEN-LAST:event_jButtonHotDogsActionPerformed

    private void jButtonSodaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSodaActionPerformed
        Clases.Golosinas peli = new Clases.Golosinas("Soda", "Palomitas Medianas", "Hot Dog", "Palomitas Grandes");
        double pSoda = 2.50;
        String p = Double.toString(pSoda);
        String[] registro = {peli.getSoda().toUpperCase(), this.jSpinnerSODA.getValue().toString(), p, Double.toString((pSoda * Double.parseDouble(this.jSpinnerSODA.getValue().toString())))};

        modeloComida.addRow(registro);
        this.txtTotalPorGolosinas.setText(Double.toString(TotalPagarGolosinas()));
        this.txtTotalPagar.setText(Double.toString(TotalPagarPagar()));
        
        this.jSpinnerSODA.setVisible(true);
        this.jLabelCUANTASODAS.setVisible(true);
    }//GEN-LAST:event_jButtonSodaActionPerformed

    public double TotalPagarPagar(){
        double totalPagarGolosinas = TotalPagarGolosinas();
        double totalPagarTicket = Double.parseDouble(this.jLabelPRECIOTOTALBOLETOS.getText());
        double totalTotalPagar = totalPagarGolosinas + totalPagarTicket;
        return totalTotalPagar;
    }
    
    public double TotalPagarGolosinas() {
        int contar = jTableCOMIDA.getRowCount();
        double sumar = 0;
        for (int i = 0; i < contar; i++) {
            sumar += Double.parseDouble(jTableCOMIDA.getValueAt(i, 3).toString());
        }
        return sumar;
    }
    
    private void jButtonPAYPALActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPAYPALActionPerformed
        this.jPanel6.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jLabelCorreo.setVisible(true);
        this.jTextFieldCorreo.setVisible(true);
        this.jButtonSALIR.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jLabelContraseniaPago.setVisible(true);
        this.jPasswordField1.setVisible(true);
        this.jLabelContraseniaPago.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_NUMTARJETA.setVisible(false);
        this.jLabelCLUB_NUMTARJETA.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NOMBRE.setVisible(false);
        this.jLabelVISA_NOMBRE.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_DUI.setVisible(false);
        this.jLabelVISA_DUI.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NUMTARJETA.setVisible(false);
        this.jLabelVISA_NUMTARJETA.setVisible(false);
    }//GEN-LAST:event_jButtonPAYPALActionPerformed

    private void jButtonTARJETA_VISAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTARJETA_VISAActionPerformed
        this.jPanel6.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_NOMBRE.setVisible(false);
        this.jLabelCLUB_NOMBRE.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_DUI.setVisible(false);
        this.jLabelCLUB_DUI.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_NUMTARJETA.setVisible(false);
        this.jLabelCLUB_NUMTARJETA.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jLabelCorreo.setVisible(false);
        this.jTextFieldCorreo.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jLabelContraseniaPago.setVisible(false);
        this.jPasswordField1.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NOMBRE.setVisible(true);
        this.jLabelVISA_NOMBRE.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_DUI.setVisible(true);
        this.jLabelVISA_DUI.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NUMTARJETA.setVisible(true);
        this.jLabelVISA_NUMTARJETA.setVisible(true);
        this.jButtonSALIR.setVisible(true);
    }//GEN-LAST:event_jButtonTARJETA_VISAActionPerformed

    private void jLabelEndGameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelEndGameMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("EndGame", "DeadPool", "BusquedaImplacable", "Pixeles", "Dumbo", "Moana", "Frozen2", "KungFuPanda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.lblAVtexto.getText().toUpperCase());

        String[] registro = {peli.getEndGame().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);

        JOptionPane.showMessageDialog(null, "Los Vengadores restantes deben encontrar una manera de recuperar a sus aliados para un enfrentamiento épico con Thanos,"
                + "\nel malvado que diezmó el planeta y el universo."
                + "\n¡Gracias por escoger Cine AWLAMA. Disfruta del final de la Saga del Infinito!", "Sinopsis: Avengers EndGame", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelEndGameMouseClicked

    private void jLabelDeadPoolMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDeadPoolMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("Avengers: End Game", "Dead Pool 2", "Busqueda Implacable", "Pixeles", "Dumbo", "Moana", "Frozen 2", "Kung Fu Panda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.lblDeadTexto.getText().toUpperCase());

        String[] registro = {peli.getDeadPool().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);
        JOptionPane.showMessageDialog(null, "Un exmercenario quien, tras haber sido sometido a un cruel experimento,"
                + "\nadquiere el superpoder de sanar rápidamente y pretende vengarse del hombre que destrozó su vida."
                + "\n¡Gracias por escoger Cine AWLAMA!", "Sinopsis: Deadpool", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelDeadPoolMouseClicked

    private void jLabelBusquedaImplacableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelBusquedaImplacableMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("Avengers: End Game", "Dead Pool 2", "Busqueda Implacable", "Pixeles", "Dumbo", "Moana", "Frozen 2", "Kung Fu Panda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.bllBusquedaTexto.getText().toUpperCase());
        
        String[] registro = {peli.getBusquedaImplacable().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);
        JOptionPane.showMessageDialog(null, "El exagente de las fuerzas especiales de élite Bryan Millis se ve enredado en la trama de una organización criminal cuando intenta salvar a su hija Kim,"
                + "\npero solo tiene 96 horas para rescatarla antes de perder el rastro."
                + "\n¡Gracias por escoger Cine AWLAMA!", "Sinopsis: Busqueda Implacable", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelBusquedaImplacableMouseClicked

    private void jLabelPixelesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelPixelesMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("Avengers: End Game", "Dead Pool 2", "Busqueda Implacable", "Pixeles", "Dumbo", "Moana", "Frozen 2", "Kung Fu Panda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.lblPixelsTexto.getText().toUpperCase());
        
        String[] registro = {peli.getPixeles().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);
        JOptionPane.showMessageDialog(null, "Un mecánico de televisión, un criminal y un teórico de la conspiración, todos ellos amigos del presidente y antiguos jugadores de élite de videojuegos,"
                + "\nson reclutados por el presidente para ayudar a salvar al país."
                + "\n¡Gracias por escoger Cine AWLAMA!", "Sinopsis: Pixels", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelPixelesMouseClicked

    private void jLabelDumboMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDumboMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("Avengers: End Game", "Dead Pool 2", "Busqueda Implacable", "Pixeles", "Dumbo", "Moana", "Frozen 2", "Kung Fu Panda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.lblDumboTexto.getText().toUpperCase());
        
        String[] registro = {peli.getDumbo().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);
        JOptionPane.showMessageDialog(null, "El dueño de un circo en aprietos contrata a un hombre y sus dos hijos para cuidar de un elefante recién nacido que puede volar,"
                + "\nque pronto se convierte en la atracción principal que revitaliza al circo."
                + "\n¡Gracias por escoger Cine AWLAMA!", "Sinopsis: Dumbo", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelDumboMouseClicked

    private void jLabelMoanaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMoanaMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("Avengers: End Game", "Dead Pool 2", "Busqueda Implacable", "Pixeles", "Dumbo", "Moana", "Frozen 2", "Kung Fu Panda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.lblMoanaTexto.getText().toUpperCase());
        
        String[] registro = {peli.getMoana().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);
        JOptionPane.showMessageDialog(null, "Vaiana Waialiki es una joven entusiasta del mar y la única hija de un jefe marinero. Cuando los marineros de su aldea no pueden pescar ningún pez y todas las cosechas fallan,"
                + "\nVaiana descubre que el semidiós Maui causó el infortunio después de robar el corazón de la diosa Te Fiti."
                + "\n¡Gracias por escoger Cine AWLAMA!", "Sinopsis: Moana", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelMoanaMouseClicked

    private void jLabelFrozenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelFrozenMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("Avengers: End Game", "Dead Pool 2", "Busqueda Implacable", "Pixeles", "Dumbo", "Moana", "Frozen 2", "Kung Fu Panda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.lblFrozenTexto.getText().toUpperCase());
        
        String[] registro = {peli.getFrozen2().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);
        JOptionPane.showMessageDialog(null, "Elsa tiene un poder extraordinario: es capaz de crear hielo y nieve."
                + "\nSin embargo, a pesar de lo feliz que la hacen los habitantes de Arendelle, siente que no encaja allá."
                + "\n¡Gracias por escoger Cine AWLAMA!", "Sinopsis: Frozen 2", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelFrozenMouseClicked

    private void jLabelKungFuPandaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelKungFuPandaMouseClicked
        Clases.Peliculas peli = new Clases.Peliculas("Avengers: End Game", "Dead Pool 2", "Busqueda Implacable", "Pixeles", "Dumbo", "Moana", "Frozen 2", "Kung Fu Panda");
        double precioBoleto = Asiento() * 2.00;
        jLabelPRECIO.setText(Integer.toString(Asiento()));
        jLabelPRECIOTOTALBOLETOS.setText(Double.toString(precioBoleto));
        jLabelPeliculaNombre.setText(this.lblKFPTexto.getText().toUpperCase());
        
        String[] registro = {peli.getKungFuPanda().toUpperCase(),
            this.jSpinnerBoletoAdulto.getValue().toString().toUpperCase(), this.jSpinnerBoletoAdultoMAyor.getValue().toString().toUpperCase(),
            this.jSpinnerBoletoÑino.getValue().toString().toUpperCase()};

        modeloPelicula.addRow(registro);
        JOptionPane.showMessageDialog(null, "El panda Po trabaja en la tienda de fideos de su familia y sueña en convertirse en un maestro del kung-fu."
                + "\nSu sueño se hace una realidad cuando es inesperadamente elegido para cumplir una antigua profecía y debe estudiar artes marciales con sus ídolos, los Cinco Furiosos."
                + "\n¡Gracias por escoger Cine AWLAMA!", "Sinopsis: Kung Fu Panda", JOptionPane.INFORMATION_MESSAGE);
        MostrarVista();
    }//GEN-LAST:event_jLabelKungFuPandaMouseClicked

    private void jButtonSIGUIENTEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSIGUIENTEActionPerformed
        String valor1 = jSpinnerBoletoAdulto.getValue().toString();
        String valor2 = jSpinnerBoletoAdultoMAyor.getValue().toString();
        String valor3 = jSpinnerBoletoÑino.getValue().toString();
        int nro1 = Integer.parseInt(valor1);
        int nro2 = Integer.parseInt(valor2);
        int nro3 = Integer.parseInt(valor3);
        int total = nro1 + nro2 + nro3;
        String t = Integer.toString(total);
        String[] registro = {this.jComboBoxSALAS.getSelectedItem().toString().toUpperCase(),
            this.jComboBoxFUNCIONES.getSelectedItem().toString().toUpperCase(), t};
        modeloSala.addRow(registro);
        this.TabbedMainPane.setEnabledAt(0, false);
        this.TabbedMainPane.setEnabledAt(1, false);
        this.TabbedMainPane.setEnabledAt(2, true);
        this.TabbedMainPane.setEnabledAt(3, true);
        this.TabbedMainPane.setEnabledAt(4, true);
    }//GEN-LAST:event_jButtonSIGUIENTEActionPerformed

    private void jButtonCONFORMAR_GOLOSINASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCONFORMAR_GOLOSINASActionPerformed
        this.jButtonSoda.setEnabled(false);
        this.jButtonHotDogs.setEnabled(false);
        this.jButtonPalomitasGrandes.setEnabled(false);
        this.jButtonPalomitasMedianas.setEnabled(false);

        this.jSpinnerSODA.setEnabled(false);
        this.jSpinnerPALOMITASM.setEnabled(false);
        this.jSpinnerHOTDOGS.setEnabled(false);
        this.jSpinnerPALOMITASG.setEnabled(false);

        this.TabbedMainPane.setEnabledAt(0, false);
        this.TabbedMainPane.setEnabledAt(1, false);
        this.TabbedMainPane.setEnabledAt(2, false);
        this.TabbedMainPane.setEnabledAt(3, true);
        this.TabbedMainPane.setEnabledAt(4, true);
    }//GEN-LAST:event_jButtonCONFORMAR_GOLOSINASActionPerformed

    private void jButtonSALIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSALIRActionPerformed
        JOptionPane.showMessageDialog(null, "Para disfrutar mejor de tu película sigue estos consejos de Cine AWLAMA"
                + "\n✰ Identifica las vías de evacuación y salida de emergencia."
                + "\n✰ No corras, ni empujes cuando entres a la sala."
                + "\n✰ Manten la calma y respesta a quien tienes al lado."
                + "\n✰ El cine somos todos - CINE AWLAMA ✰", "Cine AWLAMA: Consejos", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }//GEN-LAST:event_jButtonSALIRActionPerformed

    private void TabbedMainPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabbedMainPaneMouseClicked
    }//GEN-LAST:event_TabbedMainPaneMouseClicked

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        String filename = "Factura_CineAWLAMA.pdf";
        try {
            try (PDDocument pdfDoc = new PDDocument()) {
                PDPage pdfPag = new PDPage();
                pdfDoc.addPage(pdfPag);
                //-------------------------------------------------------------------------------------->>>>>>>
                try (PDPageContentStream contents = new PDPageContentStream(pdfDoc, pdfPag)) {
                    //logo AWLAMA
                    PDImageXObject imgAWLAMA = PDImageXObject.createFromFile("src/Pictures/mini.png", pdfDoc);
                    contents.drawImage(imgAWLAMA, 1, 700);
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 16);
                    contents.newLineAtOffset(175, 710);
                    contents.showText("CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS");
                    contents.endText();
                    //Info
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 8);
                    contents.newLineAtOffset(10, 690);
                    contents.showText("Cine AWLAMA Internet, venta de boletos de Cine AWLAMA ®, servicio proporcionado por Cine AWLAMA DE EL SALVADOR S.A. de C.V. Avenida Independencia,");
                    contents.endText();
                    //Info
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 8);
                    contents.newLineAtOffset(10, 680);
                    contents.showText("No. 3577, Interior 963, Metrocentro Santa Ana, CP 0210, Teléfono (+503) 2020-2121 en Ciudad de Santa Ana. Correo electrónico: cine-awlama@awlama.com.sv.");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(10, 640);
                    contents.showText("ESTIMADO CLIENTE, " + jTextFieldCLUB_NOMBRE.getText().toUpperCase() + jTextFieldVISA_NOMBRE.getText().toUpperCase());
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(10, 620);
                    contents.showText("Gracias por usar el servicio de Reserve AWLAMA de Cine AWLAMA®. Los datos de su compra o reservación están indicados a continuación. ");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(10, 608);
                    contents.showText("Que disfrute su función.");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(10, 580);
                    contents.showText("NÚMERO DE COMPRA O RESERVACIÓN:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(10, 560);
                    contents.showText("205240");
                    contents.endText();
                    //logo AWLAMA
                    PDImageXObject linea = PDImageXObject.createFromFile("src/Pictures/linea.png", pdfDoc);
                    contents.drawImage(linea, 1, 460);
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(10, 500);
                    contents.showText("CINE:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(10, 480);
                    contents.showText("CINE AWLAMA METROCENTRO");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(250, 500);
                    contents.showText("BOLETOS:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(250, 480);
                    contents.showText(this.jSpinnerBoletoAdulto.getValue().toString() + " x ADULTO");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(250, 460);
                    contents.showText(this.jSpinnerBoletoÑino.getValue().toString() + " x NIÑO");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(250, 440);
                    contents.showText(this.jSpinnerBoletoAdultoMAyor.getValue().toString() + " x ADULTO MAYOR");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(10, 440);
                    contents.showText("PELÍCULA:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(10, 420);
                    contents.showText(this.jLabelPeliculaNombre.getText());
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(10, 380);
                    contents.showText("SALA:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(10, 360);
                    contents.showText(this.jComboBoxSALAS.getSelectedItem().toString());
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(10, 320);
                    contents.showText("FUNCIÓN:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(10, 300);
                    contents.showText(this.jComboBoxFUNCIONES.getSelectedItem().toString());
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contents.newLineAtOffset(250, 380);
                    contents.showText("OTROS:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(250, 360);
                    contents.showText(this.jSpinnerSODA.getValue().toString() + " x "+ this.lblSodaTexto.getText());
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(250, 340);
                    contents.showText(this.jSpinnerPALOMITASM.getValue().toString() + " x "+ this.lblPalomitasMTexto.getText());
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(250, 320);
                    contents.showText(this.jSpinnerHOTDOGS.getValue().toString() + " x "+ this.lblHotDogsTexto.getText());
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 10);
                    contents.newLineAtOffset(250, 300);
                    contents.showText(this.jSpinnerPALOMITASG.getValue().toString() + " x "+ this.lblPalomitasGTexto.getText());
                    contents.endText();
                    //logo AWLAMA
                    PDImageXObject linea2 = PDImageXObject.createFromFile("src/Pictures/linea.png", pdfDoc);
                    contents.drawImage(linea2, 1, 100);
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.HELVETICA_BOLD, 14);
                    contents.newLineAtOffset(10, 100);
                    contents.showText("TOTAL DE LA COMPRA:");
                    contents.endText();
                    // CONFIRMACIÓN DE COMPRA Y RESERVA DE BOLETOS-------------
                    contents.beginText();
                    contents.setFont(PDType1Font.TIMES_ROMAN, 14);
                    contents.newLineAtOffset(250, 100);
                    contents.showText("$" + this.txtTotalPagar.getText());
                    contents.endText();
                    //logo mined
                    PDImageXObject imgMINISTERIO = PDImageXObject.createFromFile("src/Pictures/barra.png", pdfDoc);
                    contents.drawImage(imgMINISTERIO, 475, 10);
                }
                pdfDoc.save(filename);
            }
        } catch (IOException ee) {
            this.jTextArea1.setText(ee.toString());
        }
        System.out.println("Genial, PDF generado, buscar en la carpeta principal del proyecto :D");
    }//GEN-LAST:event_btnPDFActionPerformed

    private void jButtonSodaStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jButtonSodaStateChanged
    }//GEN-LAST:event_jButtonSodaStateChanged

    private void jButtonTARJETA_CLUBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTARJETA_CLUBActionPerformed
        this.jPanel6.setVisible(true);
        this.jButtonSALIR.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_NOMBRE.setVisible(true);
        this.jLabelCLUB_NOMBRE.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_DUI.setVisible(true);
        this.jLabelCLUB_DUI.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCLUB_NUMTARJETA.setVisible(true);
        this.jLabelCLUB_NUMTARJETA.setVisible(true);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NOMBRE.setVisible(false);
        this.jLabelVISA_NOMBRE.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_DUI.setVisible(false);
        this.jLabelVISA_DUI.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldVISA_NUMTARJETA.setVisible(false);
        this.jLabelContraseniaPago.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jTextFieldCorreo.setVisible(false);
        this.jLabelCorreo.setVisible(false);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        this.jLabelVISA_NUMTARJETA.setVisible(false);
        this.jPasswordField1.setVisible(false);
    }//GEN-LAST:event_jButtonTARJETA_CLUBActionPerformed

    private void jButtonAsientoD1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAsientoD1ActionPerformed
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD1ActionPerformed

    private void jButtonAsientoB4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB4MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB4MouseClicked

    private void jButtonAsientoD1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD1MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD1MouseClicked

    private void jButtonAsientoD2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD2MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD2MouseClicked

    private void txtTotalPorGolosinasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalPorGolosinasActionPerformed
    }//GEN-LAST:event_txtTotalPorGolosinasActionPerformed

    private void jButtonAsientoD3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD3MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD3MouseClicked

    private void jButtonAsientoD4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD4MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD4MouseClicked

    private void jButtonAsientoD5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD5MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD5MouseClicked

    private void jButtonAsientoD6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD6MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD6MouseClicked

    private void jButtonAsientoD7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD7MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD7MouseClicked

    private void jButtonAsientoD8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD8MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD8MouseClicked

    private void jButtonAsientoD9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD9MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD9MouseClicked

    private void jButtonAsientoD10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD10MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoD10MouseClicked

    private void jButtonAsientoC1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC1MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC1MouseClicked

    private void jButtonAsientoC2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC2MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC2MouseClicked

    private void jButtonAsientoC3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC3MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC3MouseClicked

    private void jButtonAsientoC4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC4MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC4MouseClicked

    private void jButtonAsientoC5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC5MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC5MouseClicked

    private void jButtonAsientoC6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC6MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC6MouseClicked

    private void jButtonAsientoC7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC7MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC7MouseClicked

    private void jButtonAsientoC8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC8MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC8MouseClicked

    private void jButtonAsientoC9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC9MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC9MouseClicked

    private void jButtonAsientoC10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC10MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoC10MouseClicked

    private void jButtonAsientoB1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB1MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB1MouseClicked

    private void jButtonAsientoB2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB2MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB2MouseClicked

    private void jButtonAsientoB3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB3MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB3MouseClicked

    private void jButtonAsientoB5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB5MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB5MouseClicked

    private void jButtonAsientoB6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB6MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB6MouseClicked

    private void jButtonAsientoB7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB7MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB7MouseClicked

    private void jButtonAsientoB8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB8MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB8MouseClicked

    private void jButtonAsientoB9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB9MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB9MouseClicked

    private void jButtonAsientoB10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB10MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoB10MouseClicked

    private void jButtonAsientoA1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA1MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA1MouseClicked

    private void jButtonAsientoA2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA2MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA2MouseClicked

    private void jButtonAsientoA3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA3MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA3MouseClicked

    private void jButtonAsientoA4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA4MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA4MouseClicked

    private void jButtonAsientoA5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA5MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA5MouseClicked

    private void jButtonAsientoA6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA6MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA6MouseClicked

    private void jButtonAsientoA7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA7MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA7MouseClicked

    private void jButtonAsientoA8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA8MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA8MouseClicked

    private void jButtonAsientoA9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA9MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA9MouseClicked

    private void jButtonAsientoA10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA10MouseClicked
        ValidarAsiento();
    }//GEN-LAST:event_jButtonAsientoA10MouseClicked

    private void jButtonAsientoD1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD1MousePressed
        this.jButtonAsientoD1.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD1MousePressed

    private void jButtonAsientoD2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD2MousePressed
        this.jButtonAsientoD2.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD2MousePressed

    private void jButtonAsientoD3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD3MousePressed
        this.jButtonAsientoD3.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD3MousePressed

    private void jButtonAsientoD4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD4MousePressed
        this.jButtonAsientoD4.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD4MousePressed

    private void jButtonAsientoD5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD5MousePressed
        this.jButtonAsientoD5.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD5MousePressed

    private void jButtonAsientoD6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD6MousePressed
        this.jButtonAsientoD6.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD6MousePressed

    private void jButtonAsientoD7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD7MousePressed
        this.jButtonAsientoD7.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD7MousePressed

    private void jButtonAsientoD8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD8MousePressed
        this.jButtonAsientoD8.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD8MousePressed

    private void jButtonAsientoD9MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD9MousePressed
        this.jButtonAsientoD9.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD9MousePressed

    private void jButtonAsientoD10MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoD10MousePressed
        this.jButtonAsientoD10.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoD10MousePressed

    private void jButtonAsientoC1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC1MousePressed
        this.jButtonAsientoC1.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC1MousePressed

    private void jButtonAsientoC2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC2MousePressed
        this.jButtonAsientoC2.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC2MousePressed

    private void jButtonAsientoC3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC3MousePressed
        this.jButtonAsientoC3.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC3MousePressed

    private void jButtonAsientoC4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC4MousePressed
        this.jButtonAsientoC4.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC4MousePressed

    private void jButtonAsientoC5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC5MousePressed
        this.jButtonAsientoC5.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC5MousePressed

    private void jButtonAsientoC6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC6MousePressed
        this.jButtonAsientoC6.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC6MousePressed

    private void jButtonAsientoC7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC7MousePressed
        this.jButtonAsientoC7.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC7MousePressed

    private void jButtonAsientoC8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC8MousePressed
        this.jButtonAsientoC8.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC8MousePressed

    private void jButtonAsientoC9MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC9MousePressed
        this.jButtonAsientoC9.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC9MousePressed

    private void jButtonAsientoC10MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoC10MousePressed
        this.jButtonAsientoC10.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoC10MousePressed

    private void jButtonAsientoB1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB1MousePressed
        this.jButtonAsientoB1.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB1MousePressed

    private void jButtonAsientoB2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB2MousePressed
        this.jButtonAsientoB2.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB2MousePressed

    private void jButtonAsientoB3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB3MousePressed
        this.jButtonAsientoB3.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB3MousePressed

    private void jButtonAsientoB4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB4MousePressed
        this.jButtonAsientoB4.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB4MousePressed

    private void jButtonAsientoB5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB5MousePressed
        this.jButtonAsientoB5.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB5MousePressed

    private void jButtonAsientoB6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB6MousePressed
        this.jButtonAsientoB6.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB6MousePressed

    private void jButtonAsientoB7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB7MousePressed
        this.jButtonAsientoB7.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB7MousePressed

    private void jButtonAsientoB8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB8MousePressed
        this.jButtonAsientoB8.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB8MousePressed

    private void jButtonAsientoB9MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB9MousePressed
        this.jButtonAsientoB9.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB9MousePressed

    private void jButtonAsientoB10MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoB10MousePressed
        this.jButtonAsientoB10.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoB10MousePressed

    private void jButtonAsientoA1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA1MousePressed
        this.jButtonAsientoA1.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA1MousePressed

    private void jButtonAsientoA2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA2MousePressed
        this.jButtonAsientoA2.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA2MousePressed

    private void jButtonAsientoA3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA3MousePressed
        this.jButtonAsientoA3.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA3MousePressed

    private void jButtonAsientoA4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA4MousePressed
        this.jButtonAsientoA4.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA4MousePressed

    private void jButtonAsientoA5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA5MousePressed
        this.jButtonAsientoA5.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA5MousePressed

    private void jButtonAsientoA6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA6MousePressed
        this.jButtonAsientoA6.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA6MousePressed

    private void jButtonAsientoA7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA7MousePressed
        this.jButtonAsientoA7.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA7MousePressed

    private void jButtonAsientoA8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA8MousePressed
        this.jButtonAsientoA8.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA8MousePressed

    private void jButtonAsientoA9MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA9MousePressed
        this.jButtonAsientoA9.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA9MousePressed

    private void jButtonAsientoA10MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonAsientoA10MouseMoved
        this.jButtonAsientoA10.setBackground(Color.red);
    }//GEN-LAST:event_jButtonAsientoA10MouseMoved

    private void txtTotalPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalPagarActionPerformed
    }//GEN-LAST:event_txtTotalPagarActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cine().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane TabbedMainPane;
    private javax.swing.JLabel bllBusquedaTexto;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton jButtonAsientoA1;
    private javax.swing.JButton jButtonAsientoA10;
    private javax.swing.JButton jButtonAsientoA2;
    private javax.swing.JButton jButtonAsientoA3;
    private javax.swing.JButton jButtonAsientoA4;
    private javax.swing.JButton jButtonAsientoA5;
    private javax.swing.JButton jButtonAsientoA6;
    private javax.swing.JButton jButtonAsientoA7;
    private javax.swing.JButton jButtonAsientoA8;
    private javax.swing.JButton jButtonAsientoA9;
    private javax.swing.JButton jButtonAsientoB1;
    private javax.swing.JButton jButtonAsientoB10;
    private javax.swing.JButton jButtonAsientoB2;
    private javax.swing.JButton jButtonAsientoB3;
    private javax.swing.JButton jButtonAsientoB4;
    private javax.swing.JButton jButtonAsientoB5;
    private javax.swing.JButton jButtonAsientoB6;
    private javax.swing.JButton jButtonAsientoB7;
    private javax.swing.JButton jButtonAsientoB8;
    private javax.swing.JButton jButtonAsientoB9;
    private javax.swing.JButton jButtonAsientoC1;
    private javax.swing.JButton jButtonAsientoC10;
    private javax.swing.JButton jButtonAsientoC2;
    private javax.swing.JButton jButtonAsientoC3;
    private javax.swing.JButton jButtonAsientoC4;
    private javax.swing.JButton jButtonAsientoC5;
    private javax.swing.JButton jButtonAsientoC6;
    private javax.swing.JButton jButtonAsientoC7;
    private javax.swing.JButton jButtonAsientoC8;
    private javax.swing.JButton jButtonAsientoC9;
    private javax.swing.JButton jButtonAsientoD1;
    private javax.swing.JButton jButtonAsientoD10;
    private javax.swing.JButton jButtonAsientoD2;
    private javax.swing.JButton jButtonAsientoD3;
    private javax.swing.JButton jButtonAsientoD4;
    private javax.swing.JButton jButtonAsientoD5;
    private javax.swing.JButton jButtonAsientoD6;
    private javax.swing.JButton jButtonAsientoD7;
    private javax.swing.JButton jButtonAsientoD8;
    private javax.swing.JButton jButtonAsientoD9;
    private javax.swing.JButton jButtonCONFORMAR_GOLOSINAS;
    private javax.swing.JButton jButtonHotDogs;
    private javax.swing.JButton jButtonPAYPAL;
    private javax.swing.JButton jButtonPalomitasGrandes;
    private javax.swing.JButton jButtonPalomitasMedianas;
    private javax.swing.JButton jButtonSALIR;
    private javax.swing.JButton jButtonSIGUIENTE;
    private javax.swing.JButton jButtonSoda;
    private javax.swing.JButton jButtonTARJETA_CLUB;
    private javax.swing.JButton jButtonTARJETA_VISA;
    private javax.swing.JComboBox<String> jComboBoxFUNCIONES;
    private javax.swing.JComboBox<String> jComboBoxSALAS;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JDesktopPane jDesktopPane2;
    private javax.swing.JDesktopPane jDesktopPane3;
    private javax.swing.JDesktopPane jDesktopPane4;
    private javax.swing.JDesktopPane jDesktopPane5;
    private javax.swing.JDesktopPane jDesktopPane6;
    private javax.swing.JDesktopPane jDesktopPane7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelBusquedaImplacable;
    private javax.swing.JLabel jLabelCLUB_DUI;
    private javax.swing.JLabel jLabelCLUB_NOMBRE;
    private javax.swing.JLabel jLabelCLUB_NUMTARJETA;
    private javax.swing.JLabel jLabelCUANTAHOTDOG;
    private javax.swing.JLabel jLabelCUANTASODAS;
    private javax.swing.JLabel jLabelCUANTASPALIMITASG;
    private javax.swing.JLabel jLabelCUANTASPALOMITASM1;
    private javax.swing.JLabel jLabelContraseniaPago;
    private javax.swing.JLabel jLabelCorreo;
    private javax.swing.JLabel jLabelDeadPool;
    private javax.swing.JLabel jLabelDumbo;
    private javax.swing.JLabel jLabelEndGame;
    private javax.swing.JLabel jLabelFrozen;
    private javax.swing.JLabel jLabelINDICACIONES;
    private javax.swing.JLabel jLabelKungFuPanda;
    private javax.swing.JLabel jLabelMoana;
    private javax.swing.JLabel jLabelPRECIO;
    private javax.swing.JLabel jLabelPRECIOTOTALBOLETOS;
    private javax.swing.JLabel jLabelPeliculaNombre;
    private javax.swing.JLabel jLabelPixeles;
    private javax.swing.JLabel jLabelVISA_DUI;
    private javax.swing.JLabel jLabelVISA_NOMBRE;
    private javax.swing.JLabel jLabelVISA_NUMTARJETA;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuInicio;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JPanel jPanDESPACHO_BOLETOS;
    private javax.swing.JPanel jPanDETALLE_VENTA;
    private javax.swing.JPanel jPanESCOGER_GOLOSINAS;
    private javax.swing.JPanel jPanESCOGER_SALA;
    private javax.swing.JPanel jPanMETODOS_PAGO;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSpinner jSpinnerBoletoAdulto;
    private javax.swing.JSpinner jSpinnerBoletoAdultoMAyor;
    private javax.swing.JSpinner jSpinnerBoletoÑino;
    private javax.swing.JSpinner jSpinnerHOTDOGS;
    private javax.swing.JSpinner jSpinnerPALOMITASG;
    private javax.swing.JSpinner jSpinnerPALOMITASM;
    private javax.swing.JSpinner jSpinnerSODA;
    private javax.swing.JTable jTableCOMIDA;
    private javax.swing.JTable jTablePELICULAS;
    private javax.swing.JTable jTableSALA_ASIENTOS;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextFieldCLUB_DUI;
    private javax.swing.JTextField jTextFieldCLUB_NOMBRE;
    private javax.swing.JTextField jTextFieldCLUB_NUMTARJETA;
    private javax.swing.JTextField jTextFieldCorreo;
    private javax.swing.JTextField jTextFieldVISA_DUI;
    private javax.swing.JTextField jTextFieldVISA_NOMBRE;
    private javax.swing.JTextField jTextFieldVISA_NUMTARJETA;
    private javax.swing.JLabel lblAVtexto;
    private javax.swing.JLabel lblDeadTexto;
    private javax.swing.JLabel lblDumboTexto;
    private javax.swing.JLabel lblFrozenTexto;
    private javax.swing.JLabel lblHotDogsTexto;
    private javax.swing.JLabel lblIndicacion;
    private javax.swing.JLabel lblKFPTexto;
    private javax.swing.JLabel lblMoanaTexto;
    private javax.swing.JLabel lblPalomitasGTexto;
    private javax.swing.JLabel lblPalomitasMTexto;
    private javax.swing.JLabel lblPixelsTexto;
    private javax.swing.JLabel lblSodaTexto;
    private javax.swing.JTextField txtTotalPagar;
    private javax.swing.JTextField txtTotalPorGolosinas;
    // End of variables declaration//GEN-END:variables
}
